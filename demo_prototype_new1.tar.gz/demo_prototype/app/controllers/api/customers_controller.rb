module Api
	class CustomersController < ApplicationController
		
			def getbyname
				
				customer = Customer.find_by name: request.query_parameters.values
				if customer == nil
					customer=Customer.new
					render json: {status: 'not found', message: 'no such customer found', data:customer},
				 	status:  :ok
				else
					render json: {status: 'success', message: 'fetched customer data', data:customer},
					status:  :ok
				end
			end
	end
end

















# @customers = Customer.search(params[:name])
				# customer=Customer.find(:all, :conditions => ['name LIKE ?', "%#{search}%"])
				# customer = Customer.find(params[:name])
				#customer = Customer.find_by name: 'aaa'
				#customer=request.query_parameters
				# customer = request.query_parameters.values
				# customer=Customer.new
				# customer.name=request.query_parameters.values