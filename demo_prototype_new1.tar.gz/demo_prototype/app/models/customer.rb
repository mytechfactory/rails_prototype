class Customer < ApplicationRecord
	validates :name, presence: true
	validates :age, presence: true
	validates :address, presence: true
	validates :pincode, presence: true
end
