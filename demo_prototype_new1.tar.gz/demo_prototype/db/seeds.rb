# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

customers = Customer.create([{
	name: 'aaa',
	age: '10',
	address: '123,North St.',
	pincode: '123321'
},
{
	name: 'bbb',
	age: '20',
	address: '123,South St.',
	pincode: '746536'
},
{
	name: 'ccc',
	age: '30',
	address: '123,East St.',
	pincode: '948489'
},
{
	name: 'ddd',
	age: '40',
	address: '123,West St.',
	pincode: '844378'
},
{
	name: 'eee',
	age: '50',
	address: '123,NoWhere St.',
	pincode: '746488'
}])