Rails.application.routes.draw do
  # namespace 'api' do
  # 	resources :customers
  # end
  post '/api/customers', to: 'api/customers#getbyname'
end


#get '/api/customers/:name', to: 'customers#getbyname'

  #match "/api/customers/:name" => "customers#getbyname"