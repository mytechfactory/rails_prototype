module Api
	class CustomersController < ApplicationController
		def index
				customers = Customer.order('created_at DESC');
				render json: {status: 'success', message: 'list of customers', data:customers}, status:  :ok
		end

		#########################

		def show
				customer = Customer.find(params[:id])
				render json: {status: 'success', message: 'customer found', data:customer}, status:  :ok
		end

		#########################

		def create
				customer = Customer.new(values)

				if customer.save
					render json: {status: 'success', message: 'customer added', data:customer}, status:  :ok
				else
					render json: {status: 'error', message: 'cant add the customer', 
					data:customer.errors},status:  :unprocessable_entry
				end
		end

		###########################

		def destroy
				customer = Customer.find(params[:id])
				customer.destroy

				render json: {status: 'success', message: 'deleted customer', data:customer}, status:  :ok				
		end


		###########################

			def update
				customer = Customer.find(params[:id])
				if customer.update_attributes(values)
					render json: {status: 'success', message: 'updated customer detail(s)', data:customer}, status:  :ok				
				else
					render json: {status: 'error', message: 'cant update customer detail(s)', 
					data:customer.errors},status:  :unprocessable_entry
				end
			end

		###########################

			private

			def values
				params.permit(:name, :age, :address, :pincode)
			end
	end
end